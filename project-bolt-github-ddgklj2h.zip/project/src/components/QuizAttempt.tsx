import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuizStore } from '../store/quizStore';
import { generatePDF } from '../utils/pdfGenerator';
import { Timer, AlertCircle, User, Flag, CheckCircle, X, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import clsx from 'clsx';

const QuizAttempt = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const quiz = useQuizStore((state) => state.quizzes.find(q => q.id === id));
  const { startQuiz, submitAnswer, endQuiz, currentAttempt, toggleMarkQuestion } = useQuizStore();
  const [timeLeft, setTimeLeft] = useState(0);
  const [startTime] = useState(Date.now());
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showNameDialog, setShowNameDialog] = useState(false);
  const [aspirantName, setAspirantName] = useState('');
  const [isTimeUp, setIsTimeUp] = useState(false);

  useEffect(() => {
    if (quiz && (!currentAttempt || currentAttempt.quizId !== quiz.id)) {
      startQuiz(quiz.id);
      setTimeLeft(quiz.questions.length * 60);
    }
  }, [quiz, currentAttempt]);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            setIsTimeUp(true);
            setShowNameDialog(true);
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [timeLeft]);

  if (!quiz || !currentAttempt) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="mx-auto h-12 w-12 text-red-500" />
        <h3 className="mt-2 text-lg font-medium text-gray-900">Quiz not found</h3>
      </div>
    );
  }

  const handleSubmitWithName = () => {
    const endTime = Date.now();
    endQuiz(endTime);
    const doc = generatePDF(quiz, {
      ...currentAttempt,
      endTime,
      aspirantName
    });
    doc.save(`${quiz.name}-results.pdf`);
    navigate('/');
  };

  const handleSkip = () => {
    const endTime = Date.now();
    endQuiz(endTime);
    const doc = generatePDF(quiz, {
      ...currentAttempt,
      endTime,
      aspirantName: 'Anonymous'
    });
    doc.save(`${quiz.name}-results.pdf`);
    navigate('/');
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const question = quiz.questions[currentQuestion];
  const isMarked = currentAttempt.markedQuestions.includes(question.id);

  const handleMarkQuestion = () => {
    if (!isTimeUp) {
      toggleMarkQuestion(question.id);
    }
  };

  const handleAnswerSubmit = (questionId: string, answer: number | null) => {
    if (!isTimeUp) {
      if (answer === null) {
        // Create a new answers object without the current question
        const newAnswers = { ...currentAttempt.answers };
        delete newAnswers[questionId];
        submitAnswer(questionId, undefined); // Pass undefined to clear the answer
      } else {
        submitAnswer(questionId, answer);
      }
    }
  };

  return (
    <>
      <div className="max-w-3xl mx-auto bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">{quiz.name}</h2>
          <div className="flex items-center gap-4">
            <div className="flex items-center text-gray-700">
              <Flag className="h-5 w-5 mr-2 text-red-500" />
              <span className="font-medium text-red-500">{currentAttempt.markedQuestions.length} marked</span>
            </div>
            <div className="flex items-center text-gray-700">
              <Timer className="h-5 w-5 mr-2" />
              <span className={clsx(
                "font-medium",
                timeLeft <= 60 && "text-red-500 animate-pulse"
              )}>{formatTime(timeLeft)}</span>
            </div>
          </div>
        </div>

        {/* Question Navigation */}
        <div className="mb-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-sm font-medium text-gray-700">Question Navigation</h4>
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <span>Question {currentQuestion + 1} of {quiz.questions.length}</span>
              <span>{Object.keys(currentAttempt.answers).length} answered</span>
            </div>
          </div>
          <div className="grid grid-cols-8 gap-2">
            {quiz.questions.map((q, index) => (
              <button
                key={q.id}
                onClick={() => !isTimeUp && setCurrentQuestion(index)}
                disabled={isTimeUp}
                className={clsx(
                  "h-8 w-8 rounded flex items-center justify-center text-sm transition-all",
                  currentQuestion === index && "ring-2 ring-primary",
                  currentAttempt.answers[q.id] !== undefined && "bg-green-100 text-green-700",
                  currentAttempt.markedQuestions.includes(q.id) && "bg-red-100 text-red-500 font-bold",
                  !(currentQuestion === index || currentAttempt.answers[q.id] !== undefined || currentAttempt.markedQuestions.includes(q.id)) && "bg-gray-100",
                  isTimeUp && "opacity-50 cursor-not-allowed"
                )}
              >
                {index + 1}
              </button>
            ))}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
            <div
              className="bg-indigo-600 h-2 rounded-full"
              style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
            />
          </div>
        </div>

        <div className={clsx(
          "mb-6 p-6 rounded-lg border-2 transition-colors",
          isMarked ? "border-red-500 bg-red-50" : "border-transparent"
        )}>
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-lg font-medium">{question.text}</h3>
            <button
              onClick={handleMarkQuestion}
              disabled={isTimeUp}
              className={clsx(
                "p-2 rounded-full transition-colors",
                isMarked ? "bg-red-100 text-red-500" : "bg-gray-100 text-gray-500 hover:bg-gray-200",
                isTimeUp && "opacity-50 cursor-not-allowed"
              )}
            >
              <Flag className="h-5 w-5" />
            </button>
          </div>

          {question.imageUrl && (
            <img
              src={question.imageUrl}
              alt="Question"
              className="mb-4 max-w-full h-auto rounded-lg"
            />
          )}
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSubmit(question.id, currentAttempt.answers[question.id] === index ? null : index)}
                disabled={isTimeUp}
                className={clsx(
                  "w-full text-left p-4 rounded-lg border transition-all",
                  currentAttempt.answers[question.id] === index
                    ? "border-indigo-500 bg-indigo-50"
                    : "border-gray-200 hover:bg-gray-50",
                  isTimeUp && "opacity-50 cursor-not-allowed"
                )}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="w-6">{String.fromCharCode(65 + index)}.</span>
                    <span>{option}</span>
                  </div>
                  {currentAttempt.answers[question.id] === index && (
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-indigo-500" />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAnswerSubmit(question.id, null);
                        }}
                        className="p-1 hover:bg-gray-100 rounded-full"
                        title="Clear selection"
                      >
                        <XCircle className="h-4 w-4 text-gray-400 hover:text-red-500" />
                      </button>
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex justify-between">
          <button
            onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
            disabled={currentQuestion === 0 || isTimeUp}
            className={clsx(
              "button-secondary",
              isTimeUp && "opacity-50 cursor-not-allowed"
            )}
          >
            Previous
          </button>

          {currentQuestion < quiz.questions.length - 1 ? (
            <button
              onClick={() => setCurrentQuestion(prev => Math.min(quiz.questions.length - 1, prev + 1))}
              disabled={isTimeUp}
              className={clsx(
                "button-primary",
                isTimeUp && "opacity-50 cursor-not-allowed"
              )}
            >
              Next
            </button>
          ) : (
            <button
              onClick={() => setShowNameDialog(true)}
              disabled={isTimeUp}
              className={clsx(
                "px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors",
                isTimeUp && "opacity-50 cursor-not-allowed"
              )}
            >
              Submit Quiz
            </button>
          )}
        </div>
      </div>

      <AnimatePresence>
        {showNameDialog && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-lg p-6 max-w-md w-full"
            >
              {isTimeUp && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-600">
                  <Timer className="h-5 w-5" />
                  <p>Time's up! Please submit your quiz.</p>
                </div>
              )}
              <h3 className="text-lg font-semibold mb-4">Enter Your Name (Optional)</h3>
              <div className="relative mb-4">
                <User className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={aspirantName}
                  onChange={(e) => setAspirantName(e.target.value)}
                  placeholder="Your name"
                  className="input-primary pl-10"
                />
              </div>
              <div className="flex justify-between gap-3">
                <button
                  onClick={handleSkip}
                  className="button-secondary flex items-center gap-2"
                >
                  <X className="h-4 w-4" />
                  Skip
                </button>
                <button
                  onClick={handleSubmitWithName}
                  className="button-primary"
                >
                  Generate Results
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default QuizAttempt;